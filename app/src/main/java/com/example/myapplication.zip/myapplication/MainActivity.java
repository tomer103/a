package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private int counter = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView tv_counter = findViewById(R.id.tv_counter);
        Button btn_count = findViewById(R.id.btn_count);
        Button btn_reset = findViewById(R.id.btn_reset);
        btn_count.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                counter++;
                tv_counter.setText("clicks:"+ counter);
            }
        });
        btn_reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                counter = 0;
                tv_counter.setText("clicks:"+ counter);

            }
        });

    }
}